@tool
extends MeshInstance3D

## Gerstner Wave Ocean — fully customisable
## Attach to a MeshInstance3D. All properties update live in-editor.

# ── Mesh ─────────────────────────────────────────────────────
@export_group("Mesh")
@export var mesh_size: float = 300.0 :
	set(v): mesh_size = v; _build_mesh()

@export_range(32, 512) var mesh_subdivisions: int = 256 :
	set(v): mesh_subdivisions = v; _build_mesh()

# ── Global Wave Controls ──────────────────────────────────────
@export_group("Global Wave Controls")

@export var wave_speed: float = 1.5 :
	set(v): wave_speed = v; _push_uniforms()

## Scales all wavelengths uniformly (bigger = longer, calmer waves)
@export_range(0.01, 10.0) var wave_scale: float = 1.0 :
	set(v): wave_scale = v; _push_uniforms()

## Multiplies all wave heights
@export_range(0.0, 5.0) var amplitude_mul: float = 1.0 :
	set(v): amplitude_mul = v; _push_uniforms()

## Horizontal choppiness of crests (0 = no lateral push, 1 = full)
@export_range(0.0, 2.0) var choppiness: float = 1.0 :
	set(v): choppiness = v; _push_uniforms()

## Gravity constant — affects wave propagation speed
@export_range(1.0, 30.0) var gravity: float = 9.81 :
	set(v): gravity = v; _push_uniforms()

# ── Wave A ────────────────────────────────────────────────────
@export_group("Wave A — Long Swell")
@export var wa_enabled: bool = true :
	set(v): wa_enabled = v; _push_uniforms()
@export var wa_direction: Vector2 = Vector2(1.0, 0.0) :
	set(v): wa_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wa_steepness: float = 0.40 :
	set(v): wa_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wa_wavelength: float = 40.0 :
	set(v): wa_wavelength = v; _push_uniforms()

# ── Wave B ────────────────────────────────────────────────────
@export_group("Wave B — Cross Swell")
@export var wb_enabled: bool = true :
	set(v): wb_enabled = v; _push_uniforms()
@export var wb_direction: Vector2 = Vector2(0.6, 0.8) :
	set(v): wb_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wb_steepness: float = 0.30 :
	set(v): wb_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wb_wavelength: float = 20.0 :
	set(v): wb_wavelength = v; _push_uniforms()

# ── Wave C ────────────────────────────────────────────────────
@export_group("Wave C — Chop")
@export var wc_enabled: bool = true :
	set(v): wc_enabled = v; _push_uniforms()
@export var wc_direction: Vector2 = Vector2(-0.8, 0.3) :
	set(v): wc_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wc_steepness: float = 0.25 :
	set(v): wc_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wc_wavelength: float = 9.0 :
	set(v): wc_wavelength = v; _push_uniforms()

# ── Wave D ────────────────────────────────────────────────────
@export_group("Wave D — Ripple")
@export var wd_enabled: bool = true :
	set(v): wd_enabled = v; _push_uniforms()
@export var wd_direction: Vector2 = Vector2(0.3, -0.6) :
	set(v): wd_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wd_steepness: float = 0.18 :
	set(v): wd_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wd_wavelength: float = 4.5 :
	set(v): wd_wavelength = v; _push_uniforms()

# ── Foam ──────────────────────────────────────────────────────
@export_group("Foam")
@export_range(0.0, 2.0)  var foam_threshold: float = 1.2 :
	set(v): foam_threshold = v; _push_uniforms()
@export_range(0.1, 20.0) var foam_scale: float = 2.5 :
	set(v): foam_scale = v; _push_uniforms()
@export_range(0.0, 1.0)  var foam_strength: float = 1.0 :
	set(v): foam_strength = v; _push_uniforms()
@export_range(0.0, 1.0)  var foam_roughness: float = 0.6 :
	set(v): foam_roughness = v; _push_uniforms()

# ── Colors ────────────────────────────────────────────────────
@export_group("Colors")
@export var color_shallow: Color = Color(0.05, 0.35, 0.55, 1.0) :
	set(v): color_shallow = v; _push_uniforms()
@export var color_deep: Color = Color(0.01, 0.12, 0.25, 1.0) :
	set(v): color_deep = v; _push_uniforms()
@export var color_foam: Color = Color(0.90, 0.95, 1.00, 1.0) :
	set(v): color_foam = v; _push_uniforms()
@export_range(0.0, 1.0) var depth_blend: float = 0.6 :
	set(v): depth_blend = v; _push_uniforms()

# ── Surface ───────────────────────────────────────────────────
@export_group("Surface")
@export_range(0.0, 1.0)  var metallic: float = 0.05 :
	set(v): metallic = v; _push_uniforms()
@export_range(0.0, 1.0)  var roughness: float = 0.08 :
	set(v): roughness = v; _push_uniforms()
@export_range(0.0, 1.0)  var specular_str: float = 0.5 :
	set(v): specular_str = v; _push_uniforms()
@export_range(1.0, 10.0) var fresnel_power: float = 4.0 :
	set(v): fresnel_power = v; _push_uniforms()
@export_range(0.0, 1.0)  var fresnel_str: float = 0.4 :
	set(v): fresnel_str = v; _push_uniforms()
@export_range(0.0, 1.0)  var emission_str: float = 0.04 :
	set(v): emission_str = v; _push_uniforms()
@export_range(0.0, 1.0)  var water_transparency: float = 0.0 :
	set(v): water_transparency = v; _push_uniforms()

# ─────────────────────────────────────────────────────────────
var _mat: ShaderMaterial
var _time: float = 0.0

func _ready() -> void:
	_build_mesh()
	_setup_material()

func _build_mesh() -> void:
	if not is_inside_tree():
		return
	var plane         = PlaneMesh.new()
	plane.size        = Vector2(mesh_size, mesh_size)
	plane.subdivide_width = mesh_subdivisions
	plane.subdivide_depth = mesh_subdivisions
	mesh = plane
	if _mat:
		mesh.surface_set_material(0, _mat)

func _setup_material() -> void:
	var shader_path = "res://ocean/ocean.gdshader"
	if not ResourceLoader.exists(shader_path):
		push_error("Ocean shader not found at " + shader_path)
		return
	_mat = ShaderMaterial.new()
	_mat.shader = load(shader_path)
	if mesh:
		mesh.surface_set_material(0, _mat)
	_push_uniforms()

func _push_uniforms() -> void:
	if not _mat:
		return
	# waves
	_mat.set_shader_parameter("wave_a",          Vector4(wa_direction.x, wa_direction.y, wa_steepness, wa_wavelength))
	_mat.set_shader_parameter("wave_b",          Vector4(wb_direction.x, wb_direction.y, wb_steepness, wb_wavelength))
	_mat.set_shader_parameter("wave_c",          Vector4(wc_direction.x, wc_direction.y, wc_steepness, wc_wavelength))
	_mat.set_shader_parameter("wave_d",          Vector4(wd_direction.x, wd_direction.y, wd_steepness, wd_wavelength))
	_mat.set_shader_parameter("wave_a_enabled",  1.0 if wa_enabled else 0.0)
	_mat.set_shader_parameter("wave_b_enabled",  1.0 if wb_enabled else 0.0)
	_mat.set_shader_parameter("wave_c_enabled",  1.0 if wc_enabled else 0.0)
	_mat.set_shader_parameter("wave_d_enabled",  1.0 if wd_enabled else 0.0)
	# global
	_mat.set_shader_parameter("wave_speed",      wave_speed)
	_mat.set_shader_parameter("wave_scale",      wave_scale)
	_mat.set_shader_parameter("amplitude_mul",   amplitude_mul)
	_mat.set_shader_parameter("choppiness",      choppiness)
	_mat.set_shader_parameter("gravity",         gravity)
	# foam
	_mat.set_shader_parameter("foam_threshold",  foam_threshold)
	_mat.set_shader_parameter("foam_scale",      foam_scale)
	_mat.set_shader_parameter("foam_strength",   foam_strength)
	_mat.set_shader_parameter("foam_roughness",  foam_roughness)
	# colors
	_mat.set_shader_parameter("color_shallow",   color_shallow)
	_mat.set_shader_parameter("color_deep",      color_deep)
	_mat.set_shader_parameter("color_foam",      color_foam)
	_mat.set_shader_parameter("depth_blend",     depth_blend)
	# surface
	_mat.set_shader_parameter("metallic",        metallic)
	_mat.set_shader_parameter("roughness",       roughness)
	_mat.set_shader_parameter("specular_str",    specular_str)
	_mat.set_shader_parameter("fresnel_power",   fresnel_power)
	_mat.set_shader_parameter("fresnel_str",     fresnel_str)
	_mat.set_shader_parameter("emission_str",    emission_str)
	_mat.set_shader_parameter("transparency",    water_transparency)

func _process(delta: float) -> void:
	_time += delta
	if _mat:
		_mat.set_shader_parameter("time", _time)
