@tool
extends MeshInstance3D

## Merged Ocean — Gerstner waves + SSR + Refraction + Absorption
## Attach to a MeshInstance3D. All properties update live in-editor.

# ── Mesh ─────────────────────────────────────────────────────
@export_group("Mesh")
@export var mesh_size: float = 300.0 :
	set(v): mesh_size = v; _build_mesh()

@export_range(32, 512) var mesh_subdivisions: int = 256 :
	set(v): mesh_subdivisions = v; _build_mesh()

# ── Global Wave Controls ──────────────────────────────────────
@export_group("Global Wave Controls")

@export var wave_speed: float = 1.5 :
	set(v): wave_speed = v; _push_uniforms()

@export_range(0.01, 10.0) var wave_scale: float = 1.0 :
	set(v): wave_scale = v; _push_uniforms()

@export_range(0.0, 5.0) var amplitude_mul: float = 1.0 :
	set(v): amplitude_mul = v; _push_uniforms()

@export_range(0.0, 2.0) var choppiness: float = 1.0 :
	set(v): choppiness = v; _push_uniforms()

@export_range(1.0, 30.0) var gravity: float = 9.81 :
	set(v): gravity = v; _push_uniforms()

# ── Wave A ────────────────────────────────────────────────────
@export_group("Wave A — Long Swell")
@export var wa_enabled: bool = true :
	set(v): wa_enabled = v; _push_uniforms()
@export var wa_direction: Vector2 = Vector2(1.0, 0.0) :
	set(v): wa_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wa_steepness: float = 0.40 :
	set(v): wa_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wa_wavelength: float = 40.0 :
	set(v): wa_wavelength = v; _push_uniforms()

# ── Wave B ────────────────────────────────────────────────────
@export_group("Wave B — Cross Swell")
@export var wb_enabled: bool = true :
	set(v): wb_enabled = v; _push_uniforms()
@export var wb_direction: Vector2 = Vector2(0.6, 0.8) :
	set(v): wb_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wb_steepness: float = 0.30 :
	set(v): wb_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wb_wavelength: float = 20.0 :
	set(v): wb_wavelength = v; _push_uniforms()

# ── Wave C ────────────────────────────────────────────────────
@export_group("Wave C — Chop")
@export var wc_enabled: bool = true :
	set(v): wc_enabled = v; _push_uniforms()
@export var wc_direction: Vector2 = Vector2(-0.8, 0.3) :
	set(v): wc_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wc_steepness: float = 0.25 :
	set(v): wc_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wc_wavelength: float = 9.0 :
	set(v): wc_wavelength = v; _push_uniforms()

# ── Wave D ────────────────────────────────────────────────────
@export_group("Wave D — Ripple")
@export var wd_enabled: bool = true :
	set(v): wd_enabled = v; _push_uniforms()
@export var wd_direction: Vector2 = Vector2(0.3, -0.6) :
	set(v): wd_direction = v; _push_uniforms()
@export_range(0.0, 1.0) var wd_steepness: float = 0.18 :
	set(v): wd_steepness = v; _push_uniforms()
@export_range(0.1, 200.0) var wd_wavelength: float = 4.5 :
	set(v): wd_wavelength = v; _push_uniforms()

# ── Foam ──────────────────────────────────────────────────────
@export_group("Foam")
@export_range(0.0, 2.0)  var foam_threshold: float = 1.2 :
	set(v): foam_threshold = v; _push_uniforms()
@export_range(0.0, 1.0)  var foam_strength: float = 1.0 :
	set(v): foam_strength = v; _push_uniforms()
@export_range(0.01, 0.5) var edge_size: float = 0.1 :
	set(v): edge_size = v; _push_uniforms()
@export var foam_or_fade: bool = false :
	set(v): foam_or_fade = v; _push_uniforms()

# ── Colours / Absorption ─────────────────────────────────────
@export_group("Colours")
@export var absorption_colour: Color = Color(0.05, 0.35, 0.55, 1.0) :
	set(v): absorption_colour = v; _push_uniforms()
@export_range(0.0, 5.0) var absorption_multiplier: float = 1.0 :
	set(v): absorption_multiplier = v; _push_uniforms()

# ── Optics ────────────────────────────────────────────────────
@export_group("Optics")
@export_range(0.5, 3.0) var air_ior: float = 1.0 :
	set(v): air_ior = v; _push_uniforms()
@export_range(0.5, 3.0) var water_ior: float = 1.33 :
	set(v): water_ior = v; _push_uniforms()

# ── Normal Maps ───────────────────────────────────────────────
@export_group("Normal Maps")
@export var normal1tex: Texture2D :
	set(v): normal1tex = v; _push_uniforms()
@export var normal2tex: Texture2D :
	set(v): normal2tex = v; _push_uniforms()
@export var sampler1speed: Vector2 = Vector2(0.02, 0.0) :
	set(v): sampler1speed = v; _push_uniforms()
@export var sampler2speed: Vector2 = Vector2(0.0, 0.02) :
	set(v): sampler2speed = v; _push_uniforms()
@export_range(0.0, 1.0) var samplermix: float = 0.5 :
	set(v): samplermix = v; _push_uniforms()
@export var samplerscale: Vector2 = Vector2(0.1, 0.1) :
	set(v): samplerscale = v; _push_uniforms()
@export_range(0.0, 5.0) var normalstrength: float = 1.0 :
	set(v): normalstrength = v; _push_uniforms()

# ── Height Maps ───────────────────────────────────────────────
@export_group("Height Maps")
@export var height1tex: Texture2D :
	set(v): height1tex = v; _push_uniforms()
@export var height2tex: Texture2D :
	set(v): height2tex = v; _push_uniforms()
@export_range(0.0, 5.0) var heightstrength: float = 0.12 :
	set(v): heightstrength = v; _push_uniforms()

# ── Edge / Foam Textures ──────────────────────────────────────
@export_group("Edge Textures")
@export var edge1tex: Texture2D :
	set(v): edge1tex = v; _push_uniforms()
@export var edge2tex: Texture2D :
	set(v): edge2tex = v; _push_uniforms()

# ── Refraction ────────────────────────────────────────────────
@export_group("Refraction")
## 0 = None, 1 = Simple (fast), 2 = Traced (expensive)
@export_range(0, 2) var refraction_type: int = 1 :
	set(v): refraction_type = v; _push_uniforms()
@export_range(0.0, 1.0) var simple_refraction_amount: float = 0.1 :
	set(v): simple_refraction_amount = v; _push_uniforms()
@export var traced_refraction_far_clip: float = 50.0 :
	set(v): traced_refraction_far_clip = v; _push_uniforms()
@export_range(64, 1024, 16) var traced_refraction_steps: int = 512 :
	set(v): traced_refraction_steps = v; _push_uniforms()

# ── Screen-Space Reflections ──────────────────────────────────
@export_group("Screen-Space Reflections")
## 0 = None, 1 = Simple (fast), 2 = Traced (expensive)
@export_range(0, 2) var ssr_type: int = 2 :
	set(v): ssr_type = v; _push_uniforms()
@export var traced_ssr_far_clip: float = 50.0 :
	set(v): traced_ssr_far_clip = v; _push_uniforms()
@export_range(64, 1024, 16) var traced_ssr_steps: int = 512 :
	set(v): traced_ssr_steps = v; _push_uniforms()
@export_range(0.01, 0.5) var ssr_screen_fade: float = 0.05 :
	set(v): ssr_screen_fade = v; _push_uniforms()

# ─────────────────────────────────────────────────────────────
var _mat: ShaderMaterial
var _time: float = 0.0

func _ready() -> void:
	_build_mesh()
	_setup_material()

func _build_mesh() -> void:
	if not is_inside_tree():
		return
	var plane             = PlaneMesh.new()
	plane.size            = Vector2(mesh_size, mesh_size)
	plane.subdivide_width  = mesh_subdivisions
	plane.subdivide_depth  = mesh_subdivisions
	mesh = plane
	if _mat:
		mesh.surface_set_material(0, _mat)

func _setup_material() -> void:
	var shader_path = "res://ocean/ocean.gdshader"
	if not ResourceLoader.exists(shader_path):
		push_error("Ocean shader not found at " + shader_path)
		return
	_mat = ShaderMaterial.new()
	_mat.shader = load(shader_path)
	if mesh:
		mesh.surface_set_material(0, _mat)
	_push_uniforms()

func _push_uniforms() -> void:
	if not _mat:
		return
	# Waves
	_mat.set_shader_parameter("wave_a",         Vector4(wa_direction.x, wa_direction.y, wa_steepness, wa_wavelength))
	_mat.set_shader_parameter("wave_b",         Vector4(wb_direction.x, wb_direction.y, wb_steepness, wb_wavelength))
	_mat.set_shader_parameter("wave_c",         Vector4(wc_direction.x, wc_direction.y, wc_steepness, wc_wavelength))
	_mat.set_shader_parameter("wave_d",         Vector4(wd_direction.x, wd_direction.y, wd_steepness, wd_wavelength))
	_mat.set_shader_parameter("wave_a_enabled", 1.0 if wa_enabled else 0.0)
	_mat.set_shader_parameter("wave_b_enabled", 1.0 if wb_enabled else 0.0)
	_mat.set_shader_parameter("wave_c_enabled", 1.0 if wc_enabled else 0.0)
	_mat.set_shader_parameter("wave_d_enabled", 1.0 if wd_enabled else 0.0)
	# Global
	_mat.set_shader_parameter("wave_speed",     wave_speed)
	_mat.set_shader_parameter("wave_scale",     wave_scale)
	_mat.set_shader_parameter("amplitude_mul",  amplitude_mul)
	_mat.set_shader_parameter("choppiness",     choppiness)
	_mat.set_shader_parameter("gravity",        gravity)
	# Foam
	_mat.set_shader_parameter("foam_threshold", foam_threshold)
	_mat.set_shader_parameter("foam_strength",  foam_strength)
	_mat.set_shader_parameter("edge_size",      edge_size)
	_mat.set_shader_parameter("foam_or_fade",   foam_or_fade)
	# Colours / absorption
	_mat.set_shader_parameter("absorptioncolour",     Vector3(absorption_colour.r, absorption_colour.g, absorption_colour.b))
	_mat.set_shader_parameter("absorptionmultiplier", absorption_multiplier)
	# Optics
	_mat.set_shader_parameter("AirIOR", air_ior)
	_mat.set_shader_parameter("IOR",    water_ior)
	# Textures
	_mat.set_shader_parameter("sampler1speed",  sampler1speed)
	_mat.set_shader_parameter("sampler2speed",  sampler2speed)
	_mat.set_shader_parameter("samplermix",     samplermix)
	_mat.set_shader_parameter("samplerscale",   samplerscale)
	_mat.set_shader_parameter("normalstrength", normalstrength)
	_mat.set_shader_parameter("heightstrength", heightstrength)
	if normal1tex:  _mat.set_shader_parameter("normal1tex",  normal1tex)
	if normal2tex:  _mat.set_shader_parameter("normal2tex",  normal2tex)
	if height1tex:  _mat.set_shader_parameter("height1tex",  height1tex)
	if height2tex:  _mat.set_shader_parameter("height2tex",  height2tex)
	if edge1tex:    _mat.set_shader_parameter("edge1tex",    edge1tex)
	if edge2tex:    _mat.set_shader_parameter("edge2tex",    edge2tex)
	# Refraction
	_mat.set_shader_parameter("refraction_type",             refraction_type)
	_mat.set_shader_parameter("simple_refraction_amount",    simple_refraction_amount)
	_mat.set_shader_parameter("traced_refraction_far_clip",  traced_refraction_far_clip)
	_mat.set_shader_parameter("traced_refraction_steps",     traced_refraction_steps)
	# SSR
	_mat.set_shader_parameter("ssr_type",            ssr_type)
	_mat.set_shader_parameter("traced_ssr_far_clip", traced_ssr_far_clip)
	_mat.set_shader_parameter("traced_ssr_steps",    traced_ssr_steps)
	_mat.set_shader_parameter("ssr_screen_fade",     ssr_screen_fade)

func _process(delta: float) -> void:
	_time += delta
	if _mat:
		_mat.set_shader_parameter("time", _time)
