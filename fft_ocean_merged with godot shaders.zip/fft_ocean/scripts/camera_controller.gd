extends Node3D

## Smooth orbit + pan camera for the ocean scene

@export var orbit_speed   : float = 0.3
@export var pan_speed     : float = 0.2
@export var zoom_speed    : float = 5.0
@export var min_zoom      : float = 5.0
@export var max_zoom      : float = 180.0
@export var auto_rotate   : bool  = true
@export var auto_rotate_speed: float = 0.015

var _yaw   : float = 0.0
var _pitch : float = -25.0
var _zoom  : float = 60.0
var _dragging: bool = false
var _last_mouse: Vector2 = Vector2.ZERO

@onready var camera: Camera3D = $Camera3D

func _ready() -> void:
	_apply_transform()

func _process(delta: float) -> void:
	if auto_rotate and not _dragging:
		_yaw += auto_rotate_speed * delta * 60.0
		_apply_transform()

func _input(event: InputEvent) -> void:
	if event is InputEventMouseButton:
		if event.button_index == MOUSE_BUTTON_LEFT:
			_dragging = event.pressed
			_last_mouse = event.position
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom = clamp(_zoom - zoom_speed, min_zoom, max_zoom)
			_apply_transform()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom = clamp(_zoom + zoom_speed, min_zoom, max_zoom)
			_apply_transform()

	elif event is InputEventMouseMotion and _dragging:
		var delta_mouse: Vector2 = event.position - _last_mouse
		_last_mouse = event.position
		_yaw   += delta_mouse.x * orbit_speed
		_pitch  = clamp(_pitch - delta_mouse.y * orbit_speed, -85.0, -2.0)
		_apply_transform()

func _apply_transform() -> void:
	if not camera:
		return
	var yaw_rad   = deg_to_rad(_yaw)
	var pitch_rad = deg_to_rad(_pitch)
	var offset = Vector3(
		_zoom * cos(pitch_rad) * sin(yaw_rad),
		_zoom * sin(-pitch_rad),
		_zoom * cos(pitch_rad) * cos(yaw_rad)
	)
	camera.position = offset
	camera.look_at(Vector3.ZERO, Vector3.UP)
